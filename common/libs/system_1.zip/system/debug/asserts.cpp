
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    File:   asserts.cpp
////    Author: Ritchie Brannan
////    Date:   11 Nov 10
////
////    Description:
////
////    	Debugging asserts.
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    includes
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "platforms/windows/stdafx.h"
#include "xstdio.h"
#include "log.h"
#include "asserts.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    begin debug_utils namespace
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace debug_utils
{

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    debugging support types and data
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

enum ELOG_TARGETS
{
    ELOG_TO_STDERR  = 0x00000001,
    ELOG_TO_FILE    = 0x00000002,
    ELOG_TO_DEBUG   = 0x00000004,
    ELOG_TO_DIALOG  = 0x00000008,
    ELOG_TO_BREAK   = 0x00000010,
    ELOG_TO_FORCE32 = 0x7fffffff,
};

struct LogFile
{
    const char*     name;
    file::Log*      log;
};

struct LogDesc
{
    unsigned int    count;
    unsigned int    flags;
    const char*     name;
    LogFile*        file;
};

#define LOG_DESC( name, file_id, flags )    { 0, flags, name, &log_files[ static_cast< int >( file_id ) ] }

file::Log logs[ ELOG_ID_COUNT ];

LogFile log_files[ ELOG_ID_COUNT ] =
{
    { "logs/log.txt"            , &logs[ ELOG_ID_LOG    ] },
    { "logs/info.txt"           , &logs[ ELOG_ID_INFO   ] },
    { "logs/warnings.txt"       , &logs[ ELOG_ID_WARN   ] },
    { "logs/events.txt"         , &logs[ ELOG_ID_EVENT  ] },
    { "logs/debugging.txt"      , &logs[ ELOG_ID_DEBUG  ] },
    { "logs/notifications.txt"  , &logs[ ELOG_ID_NOTIFY ] },
    { "logs/trace.txt"          , &logs[ ELOG_ID_TRACE  ] },
    { "logs/errors.txt"         , &logs[ ELOG_ID_ASSERT ] }
};

LogDesc log_descs[ ELOG_ID_COUNT ] =
{
    LOG_DESC( "LOG"    , ELOG_ID_LOG   , ELOG_TO_FILE ),
    LOG_DESC( "INFO"   , ELOG_ID_INFO  , ( ELOG_TO_FILE | ELOG_TO_DEBUG ) ),
    LOG_DESC( "WARNING", ELOG_ID_WARN  , ( ELOG_TO_FILE | ELOG_TO_DEBUG ) ),
    LOG_DESC( "EVENT"  , ELOG_ID_EVENT , ( ELOG_TO_FILE | ELOG_TO_DEBUG ) ),
    LOG_DESC( "DEBUG"  , ELOG_ID_DEBUG , ( ELOG_TO_FILE | ELOG_TO_DEBUG ) ),
    LOG_DESC( "NOTIFY" , ELOG_ID_NOTIFY, ( ELOG_TO_FILE | ELOG_TO_DEBUG | ELOG_TO_DIALOG ) ),
    LOG_DESC( "TRACE"  , ELOG_ID_TRACE , ( ELOG_TO_FILE | ELOG_TO_DEBUG ) ),
    LOG_DESC( "ASSERT" , ELOG_ID_ASSERT, ( ELOG_TO_STDERR | ELOG_TO_FILE | ELOG_TO_DEBUG | ELOG_TO_BREAK ) )
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    debugging support functions
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool debug_handler( const ELOG_ID id, const char* const string, ... )
{
	va_list args;
	va_start( args, string );
    char prefix[ 64 ];
	char buffer[ 1024 ];
	vsprintf_s( buffer, sizeof( buffer ), string, args );
    int index = static_cast< int >( id );
    if( ( index < 0 ) || ( index >= ELOG_ID_COUNT ) )
    {
        index = 0;
    }
    LogDesc& log_desc = log_descs[ 0 ];
    LogDesc& sub_desc = log_descs[ index ];
    sprintf_s( prefix, sizeof( prefix ), "[%d] (%s) ", log_desc.count, sub_desc.name );
    ++log_desc.count;
    if( index )
    {   //  anything not explicitly tagged to go via the main log gets added to the main log anyway
        if( log_desc.file != 0 )
        {
            LogFile& log_file = *log_desc.file;
            file::Log& log = *log_file.log;
            if( log.closed() )
            {
                log.open( log_file.name );
            }
            log.write( prefix );
            log.write( buffer );
        }
        sprintf_s( prefix, sizeof( prefix ), "[%d] ", sub_desc.count );
        ++sub_desc.count;
    }
    if( sub_desc.flags & ELOG_TO_STDERR )
    {
        fprintf( stderr, prefix );
        fprintf( stderr, buffer );
    }
    if( sub_desc.flags & ELOG_TO_FILE )
    {
        if( sub_desc.file != 0 )
        {
            LogFile& log_file = *sub_desc.file;
            file::Log& log = *log_file.log;
            if( log.closed() )
            {
                log.open( log_file.name );
            }
            log.write( prefix );
            log.write( buffer );
        }
    }
    if( sub_desc.flags & ELOG_TO_DEBUG )
    {
#ifdef _WIN32
         OutputDebugStringA( prefix );
         OutputDebugStringA( buffer );
#endif
    }
    if( sub_desc.flags & ELOG_TO_DIALOG )
    {
#ifdef _WIN32
        MessageBoxA( NULL, buffer, sub_desc.name, ( MB_OK | MB_ICONINFORMATION | MB_TASKMODAL ) );
#endif
    }
    if( sub_desc.flags & ELOG_TO_BREAK )
    {
#ifdef _WIN32
        int action = MessageBoxA( NULL, buffer, sub_desc.name, ( MB_ABORTRETRYIGNORE | MB_ICONSTOP | MB_TASKMODAL ) );
        if( action == IDABORT )
        {
            __debugbreak();
        }
        return( ( action == IDIGNORE ) ? false : true );
#else
        __debugbreak();
        return( false );
#endif
    }
    return( true );
}

void log_handler( const ELOG_ID id, const char* const message, ... )
{
	static const char formatting[] = "%s\n";
	va_list args;
	va_start( args, message );
    char buffer[ 1024 ];
	vsprintf_s( buffer, sizeof( buffer ), message, args );
	debug_handler( id, formatting, buffer );
}

void trace_handler( const char* const function_name, const char* const file_name, const int line_number )
{
	static const char formatting[] = "TRACE: FUNCTION(%s), FILE(%s), LINE(%d)\n";
	debug_handler( ELOG_ID_TRACE, formatting, function_name, file_name, line_number );
}

bool assert_handler( const char* const condition, const char* const function_name, const char* const file_name, const int line_number, const char* const message, ... )
{
	static const char formatting[] = \
		"\n\n"\
		"****************************************************************\n"\
		"************************    ASSERT!!    ************************\n"\
		"****************************************************************\n"\
		"CONDITION : \"%s\"\n"\
		"MESSAGE   : \"%s\"\n"\
		"FUNCTION  : \"%s\"\n"\
		"LOCATION  : \"%s\", LINE %d\n"\
		"****************************************************************\n\n";
    va_list args;
	va_start( args, message );
    char buffer[ 1024 ];
	vsprintf_s( buffer, sizeof( buffer ), message, args );
	return( debug_handler( ELOG_ID_ASSERT, formatting, condition, buffer, function_name, file_name, line_number ) );
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    end debug_utils namespace
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

};	//	namespace debug_utils

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    end of file
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

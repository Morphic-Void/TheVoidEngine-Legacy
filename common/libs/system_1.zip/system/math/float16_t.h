
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    File:   float16_t.h
////    Author: Ritchie Brannan
////    Date:   11 Nov 10
////
////    Description:
////
////    	Half precision (16-bit) floating point support class.
////
////    Notes:
////
////    	Where conversions require bit truncation, values are rounded to the nearest bit.
////    	The rounding used for bit truncation is : floor( signed value + one half bit )
////
////    	For example:
////
////    		float16_t(  0.50 ) => int( 1 )
////    		float16_t(  0.49 ) => int( 0 )
////    		float16_t( -0.50 ) => int( 0 )
////    		float16_t( -0.51 ) => int( -1 )
////    		int(  65520 ) => float16_t(  INF )
////    		int(  65519 ) => float16_t(  65504.0 )
////    		int( -65520 ) => float16_t( -65504.0 )
////    		int( -65521 ) => float16_t( -INF )
////    		float(  65520.000 ) => float16_t(  INF )
////    		float(  65519.996 ) => float16_t(  65504.0 )
////    		float( -65520.000 ) => float16_t( -65504.0 )
////    		float( -65520.004 ) => float16_t( -INF )
////
////    		float16_t() => float() : no rounding
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    include guard begin
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef	__FLOAT16_T_INCLUDED__
#define	__FLOAT16_T_INCLUDED__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    float16_t half precision (16-bit) floating point class
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class float16_t
{
public:
	inline				    float16_t() : m_bits( 0 ) {};
	inline explicit		    float16_t( const float16_t& h ) { set( h ); };
	inline explicit		    float16_t( const double d ) { set( d ); };
	inline explicit		    float16_t( const float f ) { set( f ); };
	inline explicit		    float16_t( const int i ) { set( i ); };
	inline explicit		    float16_t( const unsigned int ui ) { set( ui ); };
	inline explicit		    float16_t( const long l ) { set( l ); };
	inline explicit		    float16_t( const unsigned long ul ) { set( ul ); };
	inline explicit		    float16_t( const short s ) { set( s ); };
	inline explicit		    float16_t( const unsigned short us ) { set( us ); };
	inline explicit		    float16_t( const char c ) { set( c ); };
	inline explicit		    float16_t( const unsigned char uc ) { set( uc ); };
	inline				    ~float16_t() {};
	inline void			    init( const short bits ) { m_bits = static_cast< unsigned short >( bits ); };
	inline void			    init( const unsigned short bits ) { m_bits = bits; };
	inline bool			    sign( void ) const { return( ( m_bits & 0x8000 ) ? true : false ); };
	inline bool			    isZero( void ) const { return( ( ( m_bits & 0x7fff ) == 0x0000 ) ? true : false ); };
	inline bool			    isNAN( void ) const { return( ( ( m_bits & 0x7fff ) > 0x7c00 ) ? true : false ); };
	inline bool			    isINF( void ) const { return( ( ( m_bits & 0x7fff ) == 0x7c00 ) ? true : false ); };
	inline bool			    isReal( void ) const { return( ( ( m_bits & 0x7fff ) < 0x7c00 ) ? true : false ); };
	inline bool			    isPositive( void ) const { return( ( m_bits & 0x8000 ) ? false : true ); };
	inline bool			    isNegative( void ) const { return( ( m_bits & 0x8000 ) ? true : false ); };
	inline void			    endianSwap( void ) { m_bits = ( ( m_bits << 8 ) | ( m_bits >> 8 ) ); };
	inline void			    set( const float16_t& h ) { m_bits = h.m_bits; };
	inline void			    set( const double d ) { set( static_cast< float >( d ) ); };
	void				    set( float f );
	void				    set( int i );
	void				    set( unsigned int ui );
	inline void			    set( const long l ) { set( static_cast< int >( l ) ); };
	inline void			    set( const unsigned long ul ) { set( static_cast< unsigned int >( ul ) ); };
	inline void			    set( const short s ) { set( static_cast< int >( s ) ); };
	inline void			    set( const unsigned short us ) { set( static_cast< unsigned int >( us ) ); };
	inline void			    set( const char c ) { set( static_cast< int >( c ) ); };
	inline void			    set( const unsigned char uc ) { set( static_cast< unsigned int >( uc ) ); };
	inline float16_t&		operator=( const float16_t& h ) { set( h ); return( *this ); };
	inline float16_t&		operator=( const double d ) { set( d ); return( *this ); };
	inline float16_t&		operator=( const float f ) { set( f ); return( *this ); };
	inline float16_t&		operator=( const int i ) { set( i ); return( *this ); };
	inline float16_t&		operator=( const unsigned int ui ) { set( ui ); return( *this ); };
	inline float16_t&		operator=( const long l ) { set( l ); return( *this ); };
	inline float16_t&		operator=( const unsigned long ul ) { set( ul ); return( *this ); };
	inline float16_t&		operator=( const short s ) { set( s ); return( *this ); };
	inline float16_t&		operator=( const unsigned short us ) { set( us ); return( *this ); };
	inline float16_t&		operator=( const char c ) { set( c ); return( *this ); };
	inline float16_t&		operator=( const unsigned char uc ) { set( uc ); return( *this ); };
	inline bool			    operator==( const float16_t& h ) const { return( ( m_bits == h.m_bits ) ? true : false ); };
	inline bool			    operator!=( const float16_t& h ) const { return( ( m_bits == h.m_bits ) ? false : true ); };
	inline bool			    operator<( const float16_t& h ) const { return( ( static_cast< short >( m_bits ) < static_cast< short >( h.m_bits ) ) ? false : true ); };
	inline bool			    operator<=( const float16_t& h ) const { return( ( static_cast< short >( m_bits ) <= static_cast< short >( h.m_bits ) ) ? false : true ); };
	inline bool			    operator>( const float16_t& h ) const { return( ( static_cast< short >( m_bits ) > static_cast< short >( h.m_bits ) ) ? false : true ); };
	inline bool			    operator>=( const float16_t& h ) const { return( ( static_cast< short >( m_bits ) >= static_cast< short >( h.m_bits ) ) ? false : true ); };
	inline 				    operator double( void ) const { float f = *this; return( static_cast< double >( f ) ); };
	 					    operator float( void ) const;
						    operator int( void ) const;
						    operator unsigned int( void ) const;
	inline 				    operator long( void ) const { int i = *this; return( static_cast< long >( i ) ); };
	inline 				    operator unsigned long( void ) const { unsigned int ui = *this; return( static_cast< unsigned long >( ui ) ); };
	inline				    operator short( void ) const { int i = *this; return( static_cast< short >( ( i > 32767 ) ? 32767 : ( ( i < -32768 ) ? -32768 : i ) ) ); };
	inline				    operator unsigned short( void ) const { unsigned int ui = *this; return( static_cast< unsigned short >( ( ui > 65535 ) ? 65535 : ui ) ); };
	inline				    operator char( void ) const { int i = *this; return( static_cast< char >( ( i > 127 ) ? 127 : ( ( i < -128 ) ? -128 : i ) ) ); };
	inline				    operator unsigned char( void ) const { unsigned int ui = *this; return( static_cast< unsigned char >( ( ui > 255 ) ? 255 : ui ) ); };
private:
	unsigned short		    m_bits;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    include guard end
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif	//	#ifndef	__FLOAT16_T_INCLUDED__

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
////    End of file
////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
